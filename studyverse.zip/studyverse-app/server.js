import 'dotenv/config';
import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

import userRoutes from './routes/userRoutes.js';
import taskRoutes from './routes/taskRoutes.js';
import focusRoutes from './routes/focusRoutes.js';
import intelligenceRoutes from './routes/intelligenceRoutes.js';
import wellbeingRoutes from './routes/wellbeingRoutes.js';
import authRoutes from './routes/authRoutes.js';
import codingRoutes from './routes/codingRoutes.js';
import chatRoutes from './routes/chatRoutes.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/studyverse';

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// Serve static frontend files
app.use(express.static(path.join(__dirname, 'public')));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/focus', focusRoutes);
app.use('/api/intelligence', intelligenceRoutes);
app.use('/api/wellbeing', wellbeingRoutes);
app.use('/api/coding', codingRoutes);
app.use('/api/chat', chatRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    dbState: mongoose.connection.readyState,
    aiConfigured: Boolean(process.env.GEMINI_API_KEY)
  });
});

// Startup diagnostics
if (process.env.GEMINI_API_KEY) {
  console.log(`✅ Gemini API key loaded (${process.env.GEMINI_API_KEY.slice(0, 6)}...${process.env.GEMINI_API_KEY.slice(-4)})`);
} else {
  console.log('❌ GEMINI_API_KEY is NOT set — the AI Study Assistant chat will not work until it is added to .env and the server is restarted.');
}

// Database connection & Server Start
mongoose.connect(MONGO_URI)
  .then(() => {
    console.log('⚡ Connected to MongoDB database successfully!');
    app.listen(PORT, () => {
      console.log(`🚀 StudyVerse server running at http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('❌ MongoDB Connection Error:', err.message);
    console.log('⚠️ Starting server in memory/offline API fallback mode...');
    app.listen(PORT, () => {
      console.log(`🚀 StudyVerse server running at http://localhost:${PORT}`);
    });
  });
// Intelligence space routes active

