import User from '../models/User.js';

export async function authMiddleware(req, res, next) {
  try {
    let token = req.headers['authorization'] || req.query.userId;
    if (token && token.startsWith('Bearer ')) {
      token = token.slice(7).trim();
    }

    let user = null;
    if (token) {
      user = await User.findById(token);
    }

    // Fallback: If no token or user not found, use default seeded user
    if (!user) {
      user = await User.findOne();
      if (!user) {
        user = await User.create({ name: 'Guest Student', xp: 2480, coins: 640 });
      }
    }

    req.user = user;
    req.userId = user._id;
    next();
  } catch (error) {
    next(error);
  }
}
