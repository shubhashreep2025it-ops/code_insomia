import mongoose from 'mongoose';

const taskSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true },
  priority: { type: String, enum: ['low', 'med', 'high'], default: 'med' },
  time: { type: String, default: 'Unscheduled' },
  xp: { type: Number, default: 35 },
  coins: { type: Number, default: 10 },
  done: { type: Boolean, default: false }
}, { timestamps: true });

const Task = mongoose.model('Task', taskSchema);
export default Task;
