import mongoose from 'mongoose';

const focusSessionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  durationMinutes: { type: Number, required: true },
  sound: { type: String, default: 'none' },
  status: { type: String, enum: ['completed', 'interrupted'], default: 'completed' },
  xpEarned: { type: Number, default: 60 },
  coinsEarned: { type: Number, default: 15 }
}, { timestamps: true });

const FocusSession = mongoose.model('FocusSession', focusSessionSchema);
export default FocusSession;
