import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name: { type: String, default: 'Student' },
  username: { type: String, unique: true, sparse: true },
  email: { type: String, unique: true, sparse: true },
  password: { type: String },
  avatarUrl: { type: String, default: '' },
  greetingSub: { type: String, default: "Welcome to your study space! Add your first task to kickstart your journey." },
  xp: { type: Number, default: 0 },
  coins: { type: Number, default: 0 },
  streak: { type: Number, default: 0 },
  level: { type: Number, default: 1 },
  mood: { type: String, default: '😊' },
  consistency: { type: Number, default: 0 },
  studyTimeMinutesToday: { type: Number, default: 0 },
  codingStreak: { type: Number, default: 0 },
  problemsSolved: { type: Number, default: 0 },
  easySolved: { type: Number, default: 0 },
  mediumSolved: { type: Number, default: 0 },
  hardSolved: { type: Number, default: 0 },
  contestRating: { type: Number, default: 0 },
  lastActivityDate: { type: String, default: '' },
  brainGymScores: { type: Object, default: {} },
  leetcodeUsername: { type: String, default: '' },
  codeforcesUsername: { type: String, default: '' },
  gfgUsername: { type: String, default: '' }
}, { timestamps: true });

const User = mongoose.model('User', userSchema);
export default User;
