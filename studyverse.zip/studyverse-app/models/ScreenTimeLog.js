import mongoose from 'mongoose';

const screenTimeLogSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  dateStr: { type: String, required: true }, // Format: YYYY-MM-DD
  activeSeconds: { type: Number, default: 0 },
  activeMinutes: { type: Number, default: 0 }
}, { timestamps: true });

screenTimeLogSchema.index({ userId: 1, dateStr: 1 }, { unique: true });

const ScreenTimeLog = mongoose.model('ScreenTimeLog', screenTimeLogSchema);
export default ScreenTimeLog;
