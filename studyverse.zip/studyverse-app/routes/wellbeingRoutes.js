import express from 'express';
import User from '../models/User.js';
import ScreenTimeLog from '../models/ScreenTimeLog.js';
import { authMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();
router.use(authMiddleware);

// In-memory rest break & hydration storage per user
const userRestBreaks = {};
const userHydration = {};

// Heartbeat ping to accumulate active screen time for logged-in user
router.post('/ping-screen-time', async (req, res) => {
  try {
    const { seconds = 30 } = req.body;
    const userId = req.userId;
    const dateStr = new Date().toISOString().split('T')[0];

    let log = await ScreenTimeLog.findOne({ userId, dateStr });
    if (!log) {
      log = new ScreenTimeLog({ userId, dateStr, activeSeconds: 0, activeMinutes: 0 });
    }

    log.activeSeconds += seconds;
    log.activeMinutes = Math.floor(log.activeSeconds / 60);
    await log.save();

    // Update user study time today
    let user = req.user;
    if (user) {
      user.studyTimeMinutesToday = log.activeMinutes;
      await user.save();
    }

    res.json({ message: 'Screen time pinged!', activeMinutes: log.activeMinutes, activeSeconds: log.activeSeconds });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Smartphone-style Weekly Screen Time Report for Logged-In User
router.get('/weekly-report', async (req, res) => {
  try {
    const userId = req.userId;
    const today = new Date();
    
    // Get Mon-Sun dates for the current week
    const currentDay = today.getDay(); // 0 = Sun, 1 = Mon ...
    const distanceToMon = (currentDay + 6) % 7;
    const monday = new Date(today);
    monday.setDate(today.getDate() - distanceToMon);

    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const reportDays = [];
    let totalMinutesWeek = 0;

    for (let i = 0; i < 7; i++) {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      const dateStr = d.toISOString().split('T')[0];

      const log = await ScreenTimeLog.findOne({ userId, dateStr });
      const mins = log ? log.activeMinutes : 0;
      totalMinutesWeek += mins;

      reportDays.push({
        dayName: days[i],
        dateStr,
        minutes: mins,
        isToday: dateStr === today.toISOString().split('T')[0]
      });
    }

    const avgDailyMinutes = Math.round(totalMinutesWeek / 7);

    res.json({
      days: reportDays,
      totalMinutesWeek,
      avgDailyMinutes
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get Digital Wellbeing Metrics for Logged-In User
router.get('/', async (req, res) => {
  try {
    const user = req.user;
    const userId = req.userId.toString();

    if (!userRestBreaks[userId]) {
      userRestBreaks[userId] = [];
    }
    if (userHydration[userId] === undefined) {
      userHydration[userId] = 0;
    }

    const totalStudyTimeToday = user.studyTimeMinutesToday || 0;
    const totalRestTimeToday = userRestBreaks[userId].reduce((acc, b) => acc + b.durationMinutes, 0);

    const totalTime = totalStudyTimeToday + totalRestTimeToday;
    const screenPercentage = totalTime > 0 ? Math.round((totalStudyTimeToday / totalTime) * 100) : 0;
    const restPercentage = totalTime > 0 ? 100 - screenPercentage : 0;

    let burnoutRiskScore = 10;
    if (totalStudyTimeToday > 360) {
      burnoutRiskScore = 85;
    } else if (totalStudyTimeToday > 240) {
      burnoutRiskScore = 60;
    } else if (totalStudyTimeToday > 150) {
      burnoutRiskScore = 35;
    }

    burnoutRiskScore = Math.max(5, burnoutRiskScore - Math.floor(totalRestTimeToday / 2) - (userHydration[userId] * 2));

    let burnoutRiskLevel = 'Low Risk (Healthy Balance)';
    let riskColor = '#347A50';
    if (burnoutRiskScore >= 75) {
      burnoutRiskLevel = 'High Fatigue Alert ⚠️ Take a Break!';
      riskColor = '#C24E6E';
    } else if (burnoutRiskScore >= 45) {
      burnoutRiskLevel = 'Moderate Fatigue ⚡ Rest Recommended';
      riskColor = '#B07A22';
    }

    const minutesSinceLastBreak = totalStudyTimeToday > 0 ? Math.min(totalStudyTimeToday, 45) : 0;
    const eyeRestRecommended = totalStudyTimeToday >= 20;

    const sleepQualityIndex = Math.min(100, Math.max(50, 100 - Math.floor(totalStudyTimeToday / 20)));
    const recommendedBedtime = '10:30 PM';
    const blueLightRisk = totalStudyTimeToday > 300 ? 'High Night Strain' : totalStudyTimeToday > 120 ? 'Moderate Balance' : 'Optimal Low Strain';

    const wellnessTips = [
      { category: 'Eye Health', text: 'Follow the 20-20-20 rule: Every 20 mins, look at something 20 feet away for 20 seconds.' },
      { category: 'Posture', text: 'Keep your screen at eye level and stretch your neck every hour.' },
      { category: 'Hydration', text: 'Drink a glass of water during every study break to prevent mental fatigue.' },
      { category: 'Sleep Shield', text: 'Turn off blue light screens 45 minutes before bedtime for deep restorative sleep.' }
    ];

    res.json({
      screenTimeMinutes: totalStudyTimeToday,
      restTimeMinutes: totalRestTimeToday,
      screenPercentage,
      restPercentage,
      burnoutRiskScore,
      burnoutRiskLevel,
      riskColor,
      eyeRestRecommended,
      minutesSinceLastBreak,
      hydrationGlasses: userHydration[userId],
      targetHydration: 8,
      sleepQualityIndex,
      recommendedBedtime,
      blueLightRisk,
      loggedRestBreaks: userRestBreaks[userId],
      wellnessTips
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Log a Rest Break for Logged-In User
router.post('/rest', async (req, res) => {
  try {
    const userId = req.userId.toString();
    const { type = 'Eye Rest', durationMinutes = 5 } = req.body;
    
    if (!userRestBreaks[userId]) userRestBreaks[userId] = [];
    const newBreak = { type, durationMinutes, timestamp: new Date() };
    userRestBreaks[userId].push(newBreak);

    res.status(201).json({ message: 'Rest break logged successfully!', break: newBreak });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Log Hydration Glass for Logged-In User
router.post('/hydrate', async (req, res) => {
  try {
    const userId = req.userId.toString();
    if (!userHydration[userId]) userHydration[userId] = 0;

    if (userHydration[userId] < 8) {
      userHydration[userId] += 1;
    }

    let user = req.user;
    if (user) {
      user.xp += 10;
      user.coins += 3;
      await user.save();
    }

    res.status(200).json({ message: 'Hydration logged!', hydrationGlasses: userHydration[userId], user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Log Guided Exercise Completion for Logged-In User
router.post('/exercise', async (req, res) => {
  try {
    const userId = req.userId.toString();
    const { type = '20-20-20 Eye Exercise' } = req.body;
    
    if (!userRestBreaks[userId]) userRestBreaks[userId] = [];
    userRestBreaks[userId].push({ type, durationMinutes: 5, timestamp: new Date() });

    let user = req.user;
    if (user) {
      user.xp += 25;
      user.coins += 8;
      await user.save();
    }

    res.status(200).json({ message: 'Guided exercise completed!', user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
