import express from 'express';
import User from '../models/User.js';
import { authMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();
router.use(authMiddleware);

// In-memory submissions history per user
const userSubmissions = {};

// Submit a Coding Solution
router.post('/submit', async (req, res) => {
  try {
    const { problemTitle = 'Two Sum', difficulty = 'Medium', language = 'JavaScript', xpReward = 40, coinsReward = 12 } = req.body;
    const userId = req.userId.toString();

    let user = req.user;
    if (user) {
      user.problemsSolved += 1;
      user.codingStreak += 1;
      user.xp += xpReward;
      user.coins += coinsReward;
      user.level = Math.floor(user.xp / 200) + 1;
      user.contestRating = Math.max(1200, (user.contestRating || 0) + 15);
      await user.save();
    }

    if (!userSubmissions[userId]) userSubmissions[userId] = [];
    const submission = {
      problemTitle,
      difficulty,
      language,
      status: 'Accepted',
      xpReward,
      coinsReward,
      timestamp: new Date()
    };
    userSubmissions[userId].unshift(submission);

    res.status(200).json({
      message: 'Solution accepted! 🎉',
      submission,
      user
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get Coding Profile Stats for Logged-In User
router.get('/stats', async (req, res) => {
  try {
    const user = req.user;
    const userId = req.userId.toString();
    const submissions = userSubmissions[userId] || [];

    // Combine the in-app demo "submit" clicks with the real, persisted
    // difficulty breakdown synced from LeetCode/Codeforces so the
    // Difficulty Breakdown card reflects actual problems solved, not just
    // demo submissions.
    const easySolved = submissions.filter(s => s.difficulty === 'Easy').length + (user.easySolved || 0);
    const medSolved = submissions.filter(s => s.difficulty === 'Medium').length + (user.mediumSolved || 0);
    const hardSolved = submissions.filter(s => s.difficulty === 'Hard').length + (user.hardSolved || 0);

    res.json({
      problemsSolved: user.problemsSolved || 0,
      codingStreak: user.codingStreak || 0,
      contestRating: user.contestRating || 0,
      easySolved,
      medSolved,
      hardSolved,
      submissions
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ---------- Real coding-platform integration (LeetCode / Codeforces / GeeksforGeeks) ----------

async function fetchLeetCodeStats(username) {
  try {
    const query = `
      query userStats($username: String!) {
        matchedUser(username: $username) {
          username
          submitStats: submitStatsGlobal {
            acSubmissionNum { difficulty count }
          }
        }
        userContestRanking(username: $username) {
          rating
          globalRanking
          attendedContestsCount
        }
      }
    `;
    const response = await fetch('https://leetcode.com/graphql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Referer': 'https://leetcode.com' },
      body: JSON.stringify({ query, variables: { username } })
    });
    const json = await response.json();
    const matched = json?.data?.matchedUser;
    if (!matched) return { connected: false, error: 'Username not found on LeetCode' };

    const counts = {};
    (matched.submitStats?.acSubmissionNum || []).forEach(d => { counts[d.difficulty] = d.count; });
    const contest = json?.data?.userContestRanking;

    return {
      connected: true,
      username: matched.username,
      totalSolved: counts.All || 0,
      easySolved: counts.Easy || 0,
      mediumSolved: counts.Medium || 0,
      hardSolved: counts.Hard || 0,
      rating: contest?.rating ? Math.round(contest.rating) : null,
      globalRanking: contest?.globalRanking || null
    };
  } catch (err) {
    return { connected: false, error: 'Could not reach LeetCode right now' };
  }
}

async function fetchCodeforcesStats(handle) {
  try {
    const infoRes = await fetch(`https://codeforces.com/api/user.info?handles=${encodeURIComponent(handle)}`);
    const infoJson = await infoRes.json();
    if (infoJson.status !== 'OK') return { connected: false, error: 'Handle not found on Codeforces' };
    const info = infoJson.result[0];

    let solved = 0;
    let easySolved = 0, mediumSolved = 0, hardSolved = 0;
    try {
      const statusRes = await fetch(`https://codeforces.com/api/user.status?handle=${encodeURIComponent(handle)}`);
      const statusJson = await statusRes.json();
      if (statusJson.status === 'OK') {
        const solvedMap = new Map();
        statusJson.result.forEach(sub => {
          if (sub.verdict === 'OK') {
            const key = `${sub.problem.contestId}-${sub.problem.index}`;
            if (!solvedMap.has(key)) solvedMap.set(key, sub.problem.rating || 0);
          }
        });
        solved = solvedMap.size;
        // Bucket Codeforces problem ratings into an Easy/Medium/Hard split,
        // roughly matching typical difficulty tiers used across the app.
        for (const rating of solvedMap.values()) {
          if (!rating) continue; // unrated problems aren't counted in the breakdown
          if (rating < 1200) easySolved++;
          else if (rating < 1900) mediumSolved++;
          else hardSolved++;
        }
      }
    } catch (e) { /* submission count is best-effort */ }

    return {
      connected: true,
      handle: info.handle,
      rating: info.rating || 0,
      maxRating: info.maxRating || 0,
      rank: info.rank || 'unrated',
      solved,
      easySolved,
      mediumSolved,
      hardSolved
    };
  } catch (err) {
    return { connected: false, error: 'Could not reach Codeforces right now' };
  }
}

async function fetchGfgStats(username) {
  try {
    // Unofficial third-party API (GeeksforGeeks has no official public API).
    const response = await fetch(`https://geeks-for-geeks-api.vercel.app/${encodeURIComponent(username)}`);
    if (!response.ok) return { connected: false, error: 'Username not found on GeeksforGeeks' };
    const data = await response.json();
    const info = data.info || data;
    return {
      connected: true,
      username,
      codingScore: Number(info.codingScore) || 0,
      totalSolved: Number(info.totalProblemsSolved) || 0,
      instituteRank: info.instituteRank || null,
      currentStreak: Number(info.currentStreak) || 0
    };
  } catch (err) {
    return { connected: false, error: 'Could not reach GeeksforGeeks right now (unofficial API may be down)' };
  }
}

// Save platform usernames/handles
router.put('/platforms', async (req, res) => {
  try {
    const { leetcode, codeforces, gfg } = req.body;
    const user = req.user;
    if (leetcode !== undefined) user.leetcodeUsername = String(leetcode).trim();
    if (codeforces !== undefined) user.codeforcesUsername = String(codeforces).trim();
    if (gfg !== undefined) user.gfgUsername = String(gfg).trim();
    await user.save();
    res.json({
      message: 'Platform usernames saved',
      leetcodeUsername: user.leetcodeUsername,
      codeforcesUsername: user.codeforcesUsername,
      gfgUsername: user.gfgUsername
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Fetch live stats for whichever platforms the user has connected
router.get('/platforms', async (req, res) => {
  try {
    const user = req.user;
    const [leetcode, codeforces, gfg] = await Promise.all([
      user.leetcodeUsername ? fetchLeetCodeStats(user.leetcodeUsername) : Promise.resolve({ connected: false, error: 'Not connected' }),
      user.codeforcesUsername ? fetchCodeforcesStats(user.codeforcesUsername) : Promise.resolve({ connected: false, error: 'Not connected' }),
      user.gfgUsername ? fetchGfgStats(user.gfgUsername) : Promise.resolve({ connected: false, error: 'Not connected' })
    ]);

    // Persist the real combined totals onto the user record so that every other
    // screen (dashboard tiles, /coding/stats, the 5s auto-poll) reads the same
    // live numbers instead of the old demo/"submit" counters, which used to
    // silently overwrite the synced values a few seconds after every sync.
    const combinedSolved = (leetcode.totalSolved || 0) + (codeforces.solved || 0) + (gfg.totalSolved || 0);
    const anyConnected = leetcode.connected || codeforces.connected || gfg.connected;

    if (anyConnected) {
      if (combinedSolved > 0) user.problemsSolved = combinedSolved;

      // Real difficulty breakdown: LeetCode reports it directly, Codeforces is
      // bucketed by problem rating (see fetchCodeforcesStats). GfG's unofficial
      // API doesn't expose a per-difficulty split, so it isn't included here.
      const easySolved = (leetcode.connected ? leetcode.easySolved || 0 : 0) + (codeforces.connected ? codeforces.easySolved || 0 : 0);
      const mediumSolved = (leetcode.connected ? leetcode.mediumSolved || 0 : 0) + (codeforces.connected ? codeforces.mediumSolved || 0 : 0);
      const hardSolved = (leetcode.connected ? leetcode.hardSolved || 0 : 0) + (codeforces.connected ? codeforces.hardSolved || 0 : 0);
      if (leetcode.connected || codeforces.connected) {
        user.easySolved = easySolved;
        user.mediumSolved = mediumSolved;
        user.hardSolved = hardSolved;
      }

      // Prefer a real rating from a connected platform over the fake demo rating.
      const realRating = leetcode.rating || (codeforces.connected ? codeforces.rating : null);
      if (realRating) user.contestRating = realRating;

      // GfG is the only platform that reports an actual daily streak; use it
      // when available instead of the fake per-submit counter.
      if (gfg.connected && typeof gfg.currentStreak === 'number') {
        user.codingStreak = gfg.currentStreak;
      }

      await user.save();
    }

    res.json({
      leetcode: { ...leetcode, username: user.leetcodeUsername || '' },
      codeforces: { ...codeforces, username: user.codeforcesUsername || '' },
      gfg: { ...gfg, username: user.gfgUsername || '' },
      problemsSolved: user.problemsSolved,
      codingStreak: user.codingStreak,
      contestRating: user.contestRating,
      easySolved: user.easySolved,
      mediumSolved: user.mediumSolved,
      hardSolved: user.hardSolved
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
