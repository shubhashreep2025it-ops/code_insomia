import express from 'express';
import { authMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();
router.use(authMiddleware);

const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const getGeminiUrl = () => `https://generativelanguage.googleapis.com/v1beta/models/${process.env.GEMINI_MODEL || GEMINI_MODEL}:generateContent`;

const SYSTEM_INSTRUCTION =
  "You are the StudyVerse AI Study Assistant — a warm, encouraging companion built into a student " +
  "productivity app. Help with study plans, explaining academic topics simply, revision techniques, " +
  "focus tips, and motivation. Keep replies concise, practical, and easy to scan (short paragraphs or " +
  "bullet points). Never mention which underlying AI model or provider powers you.";

// POST /api/chat — send a message to the AI Study Assistant and get a reply
router.post('/', async (req, res) => {
  try {
    const { message, history } = req.body;

    if (!message || !String(message).trim()) {
      return res.status(400).json({ error: 'A message is required.' });
    }

    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: 'AI assistant is not configured. Missing API key on the server.' });
    }

    // Build conversation contents from recent history (keep last 10 turns for context)
    const contents = [];
    if (Array.isArray(history)) {
      for (const turn of history.slice(-10)) {
        if (!turn || !turn.text) continue;
        contents.push({
          role: turn.role === 'user' ? 'user' : 'model',
          parts: [{ text: String(turn.text) }]
        });
      }
    }
    contents.push({ role: 'user', parts: [{ text: String(message) }] });

    const response = await fetch(getGeminiUrl(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-goog-api-key': process.env.GEMINI_API_KEY
      },
      body: JSON.stringify({
        contents,
        systemInstruction: { parts: [{ text: SYSTEM_INSTRUCTION }] },
        generationConfig: { temperature: 0.8, maxOutputTokens: 800 }
      })
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('Gemini API error:', data?.error || data);
      return res.status(502).json({ error: data?.error?.message || 'The AI assistant could not respond right now.' });
    }

    const reply = data?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('').trim();

    if (!reply) {
      return res.json({ reply: "Hmm, I couldn't quite form a response to that — could you try rephrasing it?" });
    }

    res.json({ reply });
  } catch (error) {
    console.error('Chat route error:', error);
    res.status(500).json({ error: error.message || 'Something went wrong talking to the AI assistant.' });
  }
});

export default router;
