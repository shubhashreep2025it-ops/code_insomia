import express from 'express';
import FocusSession from '../models/FocusSession.js';
import { authMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();
router.use(authMiddleware);

// Helper for local YYYY-MM-DD date string
function getLocalDateStr(d = new Date()) {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Recalculate streak from FocusSession history
async function recalcStreak(userId) {
  const sessions = await FocusSession.find({ userId }).sort({ createdAt: 1 });

  // Get unique local date strings from all sessions
  const dateSet = new Set();
  sessions.forEach(s => dateSet.add(getLocalDateStr(s.createdAt)));
  const dates = [...dateSet].sort().reverse(); // newest first

  if (dates.length === 0) return 0;

  const today = new Date();
  const todayStr = getLocalDateStr(today);
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  const yesterdayStr = getLocalDateStr(yesterday);

  // Streak is only valid if most recent activity was today or yesterday
  if (dates[0] !== todayStr && dates[0] !== yesterdayStr) return 0;

  let streak = 1;
  for (let i = 0; i < dates.length - 1; i++) {
    const d1 = new Date(dates[i]);
    const d2 = new Date(dates[i + 1]);
    const diffDays = Math.round((d1 - d2) / (1000 * 60 * 60 * 24));
    if (diffDays === 1) streak++;
    else break;
  }
  return streak;
}

// Log a Focus Session for Logged-In User
router.post('/log', async (req, res) => {
  try {
    const { durationMinutes = 25, sound = 'none', status = 'completed', xpEarned = 60, coinsEarned = 15 } = req.body;
    
    const actualXp = status === 'completed' ? xpEarned : Math.floor(xpEarned * 0.2);
    const actualCoins = status === 'completed' ? coinsEarned : 0;

    const session = await FocusSession.create({
      userId: req.userId,
      durationMinutes,
      sound,
      status,
      xpEarned: actualXp,
      coinsEarned: actualCoins
    });

    let user = req.user;
    if (user) {
      user.xp += actualXp;
      user.coins += actualCoins;

      const todayStr = getLocalDateStr();

      // Reset daily study time if a new day has started
      if (user.lastActivityDate && user.lastActivityDate !== todayStr) {
        user.studyTimeMinutesToday = 0;
      }

      if (status === 'completed') {
        user.studyTimeMinutesToday += durationMinutes;
      }

      user.level = Math.floor(user.xp / 200) + 1;
      user.lastActivityDate = todayStr;

      // Recalculate streak
      user.streak = await recalcStreak(req.userId);
      
      await user.save();
    }

    res.status(201).json({ session, user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get Focus Session History for Logged-In User
router.get('/', async (req, res) => {
  try {
    const sessions = await FocusSession.find({ userId: req.userId }).sort({ createdAt: -1 }).limit(20);
    res.json(sessions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get 365-Day Activity Heatmap Data for Logged-In User
router.get('/heatmap', async (req, res) => {
  try {
    const oneYearAgo = new Date();
    oneYearAgo.setDate(oneYearAgo.getDate() - 365);

    const sessions = await FocusSession.find({
      userId: req.userId,
      createdAt: { $gte: oneYearAgo }
    });

    // Only use LOCAL date key (prevents duplicate UTC offset coloring)
    const activityMap = {};
    sessions.forEach(s => {
      const dateKey = getLocalDateStr(s.createdAt);
      activityMap[dateKey] = (activityMap[dateKey] || 0) + s.durationMinutes;
    });

    // Merge today's live study time from user profile
    const todayStr = getLocalDateStr();
    const userMins = req.user ? (req.user.studyTimeMinutesToday || 0) : 0;
    if (userMins > 0) {
      activityMap[todayStr] = Math.max(activityMap[todayStr] || 0, userMins);
    }

    res.json(activityMap);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET: Current user streak (recalculated live)
router.get('/streak', async (req, res) => {
  try {
    const streak = await recalcStreak(req.userId);
    if (req.user) {
      req.user.streak = streak;
      await req.user.save();
    }
    res.json({ streak });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
