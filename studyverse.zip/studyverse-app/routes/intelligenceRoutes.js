import express from 'express';
import Task from '../models/Task.js';
import FocusSession from '../models/FocusSession.js';
import { authMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();
router.use(authMiddleware);

// Get Intelligence Analytics for Logged-In User
router.get('/', async (req, res) => {
  try {
    const tasks = await Task.find({ userId: req.userId });
    const sessions = await FocusSession.find({ userId: req.userId });

    // Task Analytics
    const totalTasks = tasks.length;
    const completedTasks = tasks.filter(t => t.done).length;
    const pendingTasks = totalTasks - completedTasks;
    const taskSuccessRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
    const taskFailureRate = totalTasks > 0 ? 100 - taskSuccessRate : 0;

    // Priority Breakdown
    const getPriorityStats = (p) => {
      const filtered = tasks.filter(t => t.priority === p);
      const doneCount = filtered.filter(t => t.done).length;
      const rate = filtered.length > 0 ? Math.round((doneCount / filtered.length) * 100) : 0;
      return { total: filtered.length, completed: doneCount, rate };
    };

    const priorityBreakdown = {
      high: getPriorityStats('high'),
      med: getPriorityStats('med'),
      low: getPriorityStats('low')
    };

    // Focus Session Analytics
    const totalFocusSessions = sessions.length;
    const interruptedFocusSessions = sessions.filter(s => s.status === 'interrupted').length;
    const completedFocusSessions = totalFocusSessions - interruptedFocusSessions;
    const focusSuccessRate = totalFocusSessions > 0 ? Math.round((completedFocusSessions / totalFocusSessions) * 100) : 0;
    const focusFailureRate = totalFocusSessions > 0 ? 100 - focusSuccessRate : 0;

    // Dynamic Productivity Intelligence Index (0–100)
    const productivityIndex = totalTasks > 0 ? Math.round((taskSuccessRate * 0.6) + (focusSuccessRate * 0.4)) : 0;

    // Dynamic AI Study Insights
    const aiInsights = [];

    if (totalTasks === 0) {
      aiInsights.push({ type: 'info', text: '💡 Welcome to Intelligence Space! Add tasks in your planner to activate AI performance tracking and success rate calculations.' });
    } else {
      if (taskSuccessRate >= 80) {
        aiInsights.push({ type: 'success', text: '🔥 Excellent task completion rate! You are maintaining peak productivity momentum.' });
      } else if (taskSuccessRate >= 50) {
        aiInsights.push({ type: 'info', text: '⚡ Good progress! Focusing on pending High Priority tasks will boost your overall success score.' });
      } else {
        aiInsights.push({ type: 'warning', text: '⚠️ High pending task load detected. Consider tackling 1-2 small tasks to regain momentum.' });
      }

      if (priorityBreakdown.high.rate < 50 && priorityBreakdown.high.total > 0) {
        aiInsights.push({ type: 'warning', text: '🎯 High Priority success rate is below 50%. Prioritize these tasks earlier in your study sessions.' });
      } else if (priorityBreakdown.high.rate >= 80 && priorityBreakdown.high.total > 0) {
        aiInsights.push({ type: 'success', text: '🏆 You excel at completing urgent tasks on time!' });
      }
    }

    if (totalFocusSessions > 0) {
      if (focusFailureRate > 20) {
        aiInsights.push({ type: 'warning', text: '🎧 Focus session interruptions registered. Try enabling Lo-Fi Rain ambient sounds to block distractions.' });
      } else {
        aiInsights.push({ type: 'success', text: '🧠 Great focus retention! Minimal session interruptions recorded.' });
      }
    }

    res.json({
      taskStats: {
        totalTasks,
        completedTasks,
        pendingTasks,
        taskSuccessRate,
        taskFailureRate
      },
      priorityBreakdown,
      focusStats: {
        totalFocusSessions,
        completedFocusSessions,
        interruptedFocusSessions,
        focusSuccessRate,
        focusFailureRate
      },
      productivityIndex,
      aiInsights
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
