import express from 'express';
import Task from '../models/Task.js';
import { authMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();
router.use(authMiddleware);

// Get Tasks for Logged-In User
router.get('/', async (req, res) => {
  try {
    const tasks = await Task.find({ userId: req.userId }).sort({ createdAt: -1 });
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Add Task for Logged-In User
router.post('/', async (req, res) => {
  try {
    const { title, priority, time } = req.body;
    const xp = priority === 'high' ? 50 : priority === 'med' ? 35 : 20;
    const coins = 10;
    const task = await Task.create({
      userId: req.userId,
      title,
      priority,
      time: time || 'Unscheduled',
      xp,
      coins
    });
    res.status(201).json(task);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Toggle Task
router.put('/:id/toggle', async (req, res) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, userId: req.userId });
    if (!task) return res.status(404).json({ error: 'Task not found' });

    task.done = !task.done;
    await task.save();

    let user = req.user;
    if (user) {
      if (task.done) {
        user.xp += task.xp;
        user.coins += task.coins;
        user.consistency = Math.min(100, user.consistency + 5);
      } else {
        user.xp = Math.max(0, user.xp - task.xp);
        user.coins = Math.max(0, user.coins - task.coins);
      }
      user.level = Math.floor(user.xp / 200) + 1;
      await user.save();
    }

    res.json({ task, user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete Task
router.delete('/:id', async (req, res) => {
  try {
    await Task.findOneAndDelete({ _id: req.params.id, userId: req.userId });
    res.json({ message: 'Task deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
