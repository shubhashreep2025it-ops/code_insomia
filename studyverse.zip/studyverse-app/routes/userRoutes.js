import express from 'express';
import User from '../models/User.js';
import { authMiddleware } from '../middleware/authMiddleware.js';

const router = express.Router();
router.use(authMiddleware);

// Get User Profile for Logged-In User
router.get('/', async (req, res) => {
  try {
    const user = req.user;
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update Avatar Picture (Base64 string or Preset URL)
router.put('/avatar', async (req, res) => {
  try {
    const { avatarUrl } = req.body;
    let user = req.user;
    user.avatarUrl = avatarUrl || '';
    await user.save();
    res.json({ message: 'Profile avatar updated successfully!', avatarUrl: user.avatarUrl, user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update Profile Details (Name, Greeting)
router.put('/profile', async (req, res) => {
  try {
    const { name, greetingSub } = req.body;
    let user = req.user;
    if (name) user.name = name.trim();
    if (greetingSub) user.greetingSub = greetingSub.trim();
    await user.save();
    res.json({ message: 'Profile updated successfully!', user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update Mood
router.put('/mood', async (req, res) => {
  try {
    const { mood, greetingSub } = req.body;
    let user = req.user;
    user.mood = mood || user.mood;
    user.greetingSub = greetingSub || user.greetingSub;
    await user.save();
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Purchase Reward
router.put('/buy-reward', async (req, res) => {
  try {
    const { cost } = req.body;
    let user = req.user;
    if (user.coins < cost) {
      return res.status(400).json({ error: 'Not enough coins' });
    }
    user.coins -= cost;
    await user.save();
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update Stats (Add XP & Coins)
router.put('/stats', async (req, res) => {
  try {
    const { xpToAdd, coinsToAdd } = req.body;
    let user = req.user;
    
    user.xp += (xpToAdd || 0);
    user.coins += (coinsToAdd || 0);
    user.level = Math.floor(user.xp / 200) + 1;

    await user.save();
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
