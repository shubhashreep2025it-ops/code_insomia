import express from 'express';
import crypto from 'crypto';
import User from '../models/User.js';
import FocusSession from '../models/FocusSession.js';

// Helper for local date string
function getLocalDateStr(d = new Date()) {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

async function recalcStreak(userId) {
  const sessions = await FocusSession.find({ userId }).sort({ createdAt: 1 });
  const dateSet = new Set();
  sessions.forEach(s => dateSet.add(getLocalDateStr(s.createdAt)));
  const dates = [...dateSet].sort().reverse();
  if (dates.length === 0) return 0;
  const today = new Date();
  const todayStr = getLocalDateStr(today);
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  const yesterdayStr = getLocalDateStr(yesterday);
  if (dates[0] !== todayStr && dates[0] !== yesterdayStr) return 0;
  let streak = 1;
  for (let i = 0; i < dates.length - 1; i++) {
    const d1 = new Date(dates[i]);
    const d2 = new Date(dates[i + 1]);
    const diffDays = Math.round((d1 - d2) / (1000 * 60 * 60 * 24));
    if (diffDays === 1) streak++;
    else break;
  }
  return streak;
}

const router = express.Router();

// Helper to hash password
function hashPassword(password, salt = 'studyverse_secret_salt_2026') {
  return crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
}

// Sanitize user output (remove sensitive password field)
function sanitizeUser(user) {
  const u = user.toObject ? user.toObject() : { ...user };
  delete u.password;
  return u;
}

// REGISTER NEW USER (Username, Email, Password)
router.post('/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ error: 'Username, Email, and Password are all required.' });
    }

    const cleanEmail = email.trim().toLowerCase();
    const cleanUsername = username.trim();

    // Check existing account
    const existingUser = await User.findOne({
      $or: [{ email: cleanEmail }, { username: cleanUsername }]
    });

    if (existingUser) {
      return res.status(400).json({ error: 'An account with this email or username already exists.' });
    }

    const hashedPassword = hashPassword(password);

    const user = await User.create({
      name: cleanUsername,
      username: cleanUsername,
      email: cleanEmail,
      password: hashedPassword,
      greetingSub: "Welcome to your study space! Add your first task to kickstart your journey.",
      xp: 0,
      coins: 0,
      streak: 0,
      level: 1,
      mood: '😊',
      consistency: 0,
      studyTimeMinutesToday: 0,
      codingStreak: 0,
      problemsSolved: 0
    });

    res.status(201).json({
      message: 'Account registered successfully!',
      token: user._id,
      user: sanitizeUser(user)
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// LOGIN USER (Email/Username & Password)
router.post('/login', async (req, res) => {
  try {
    const { loginIdentifier, password } = req.body;

    if (!loginIdentifier || !password) {
      return res.status(400).json({ error: 'Please provide Email/Username and Password.' });
    }

    const cleanIdentifier = loginIdentifier.trim().toLowerCase();
    const hashedPassword = hashPassword(password);

    const user = await User.findOne({
      $or: [
        { email: cleanIdentifier },
        { username: cleanIdentifier },
        { name: loginIdentifier.trim() }
      ]
    });

    if (!user) {
      return res.status(404).json({ error: 'Account not found. Please check your credentials or Register.' });
    }

    if (user.password && user.password !== hashedPassword) {
      return res.status(401).json({ error: 'Incorrect password. Please try again.' });
    }

    // If legacy user without password logged in for first time, set password
    if (!user.password) {
      user.password = hashedPassword;
      user.email = user.email || cleanIdentifier;
      user.username = user.username || user.name;
      await user.save();
    }

    res.json({
      message: 'Login successful!',
      token: user._id,
      user: sanitizeUser(user)
    });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET CURRENT LOGGED-IN USER PROFILE
router.get('/me', async (req, res) => {
  try {
    const userId = req.headers['authorization'] || req.query.userId;

    if (!userId) {
      return res.status(401).json({ error: 'Authentication required. Please log in.' });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User session expired. Please log in again.' });
    }

    // Always recalculate streak from actual focus session history
    const calculatedStreak = await recalcStreak(user._id);
    user.streak = calculatedStreak;

    // Reset daily study time if a new day started
    const todayStr = getLocalDateStr();
    if (user.lastActivityDate && user.lastActivityDate !== todayStr) {
      user.studyTimeMinutesToday = 0;
    }

    await user.save();
    res.json(sanitizeUser(user));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
