import 'dotenv/config';
import mongoose from 'mongoose';
import User from '../models/User.js';

// Sets the dashboard "day streak" (the streakPill at the top of the app,
// and the Profile page's "Current Streak" card) to 1 for every user.
// Run with: node scripts/setStreak.js
async function setStreak() {
  try {
    const uri = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/studyverse';
    await mongoose.connect(uri);
    const result = await User.updateMany({}, { $set: { streak: 1 } });
    console.log(`✅ Set streak to 1 for ${result.modifiedCount} user account(s).`);
    await mongoose.disconnect();
  } catch (err) {
    console.error('Error setting streak:', err.message);
  }
}

setStreak();
