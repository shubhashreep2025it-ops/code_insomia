import mongoose from 'mongoose';
import User from '../models/User.js';

async function resetAllUsers() {
  try {
    await mongoose.connect('mongodb://127.0.0.1:27017/studyverse');
    const result = await User.updateMany({}, {
      $set: {
        streak: 0,
        xp: 0,
        coins: 0,
        level: 1,
        consistency: 0,
        studyTimeMinutesToday: 0,
        codingStreak: 0,
        problemsSolved: 0
      }
    });
    console.log(`✅ Successfully reset ${result.modifiedCount} user accounts to 100% zero baseline!`);
    await mongoose.disconnect();
  } catch (err) {
    console.error('Error resetting users:', err.message);
  }
}

resetAllUsers();
